import{initializeApp}from"https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import{getAuth,onAuthStateChanged,signInWithPopup,GoogleAuthProvider,signOut}from"https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
const app=initializeApp({apiKey:"AIzaSyBs4riAcCJv8MZDoD5VShqNWUH7lbOQycs",authDomain:"voxai-ccf15.firebaseapp.com",projectId:"voxai-ccf15",appId:"1:222065075873:web:246b2ce6ccbd4be1aa72e0"});
export const auth=getAuth(app);
export const login=()=>signInWithPopup(auth,new GoogleAuthProvider());
export const logout=()=>signOut(auth).then(()=>location.href="/login.html");
export const user=()=>new Promise(r=>{const o=onAuthStateChanged(auth,x=>{o();r(x)})});
export async function api(path,o={}){
  const u=auth.currentUser,t=u?await u.getIdToken():"";
  const r=await fetch("/api"+path,{...o,headers:{"content-type":"application/json",authorization:"Bearer "+t},body:o.body?JSON.stringify(o.body):undefined});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw Object.assign(new Error(d.error||"Erro "+r.status),{status:r.status,data:d});
  return d;
}
