import{api,user}from"/auth.js";
const $=i=>document.getElementById(i);
const h=(t,p={},...c)=>{const e=document.createElement(t);Object.assign(e,p);e.append(...c);return e};
const toast=t=>{const e=$("toast");e.textContent=t;e.style.display="block";setTimeout(()=>e.style.display="none",4000)};
const u=await user();if(!u)location.href="/login.html";
try{if(!(await api("/me")).isAdmin)throw 0}catch{$("lt").textContent="Acesso negado. Redirecionando...";setTimeout(()=>location.href="/index.html",1800);throw 0}
$("lock").style.display="none";$("app").style.display="flex";
let D={},tab="dash";
const T={dash:"Dashboard",users:"Usuários",adm:"Administradores",ia:"Controle da IA",msg:"Mensagem global"};
async function load(){
  const[us,ls,st,ms]=await Promise.all([api("/admins/users"),api("/admins"),api("/states/ai"),api("/msg")]);
  D={users:us.users,L:ls,st,ms};draw();
}
const act=async(fn,ok)=>{try{await fn();toast(ok);await load()}catch(e){toast(e.message)}};
const stat=(l,v)=>h("div",{className:"glass stat"},h("small",{textContent:l}),h("div",{textContent:String(v)}));
const pan=(t,...c)=>h("div",{className:"glass pan"},h("h2",{textContent:t}),...c);
function draw(){
  $("nav").replaceChildren(...Object.entries(T).map(([k,v])=>h("button",{className:tab===k?"on":"",textContent:v,onclick:()=>{tab=k;draw()}})));
  const c=$("cont"),{users,L,st,ms}=D,bn=users.filter(x=>x.status==="banned").length;c.replaceChildren(h("h1",{textContent:T[tab],style:"margin-bottom:16px"}));
  if(tab==="dash")c.append(h("div",{className:"grid"},stat("Usuários totais",users.length),stat("Ativos",users.length-bn),stat("Banidos",bn),stat("Administradores",L.admins.length),stat("IA",st.enabled?"Online":"Offline"),stat("Manutenção",st.maintenance?"Ligada":"Desligada"),stat("Mensagem global",ms.enabled?"Ativa":"Inativa")));
  if(tab==="users")c.append(pan("Usuários reais (quem já entrou no CoreBrainVox)",...(users.length?users:[]).map(x=>h("div",{className:"row"},
    h("img",{src:x.photo||"/logo.svg",alt:""}),
    h("div",{className:"i"},h("b",{textContent:x.name||"(sem nome)"}),h("small",{textContent:x.email}),h("small",{textContent:"UID "+x.uid}),h("small",{textContent:"Criado "+new Date(x.createdAt).toLocaleString("pt-BR")+" · Último login "+new Date(x.lastLogin).toLocaleString("pt-BR")}),x.ban?h("small",{textContent:"Motivo: "+(x.ban.reason||"—")+(x.ban.until?" · até "+new Date(x.ban.until).toLocaleString("pt-BR"):"")}):""),
    h("span",{className:"tag"+(x.status==="banned"?" b":""),textContent:x.status==="banned"?"banido":"ativo"}),
    x.isAdmin?h("span",{className:"tag",textContent:"admin"}):x.status==="banned"
      ?h("button",{className:"btn",textContent:"Desbanir",onclick:()=>act(()=>api("/admins/unban",{method:"POST",body:{uid:x.uid}}),"Usuário desbanido")})
      :h("button",{className:"btn dan",textContent:"Banir",onclick:()=>{const r=prompt("Motivo do banimento:");if(r===null)return;const d=prompt("Duração em minutos (vazio = permanente):");act(()=>api("/admins/ban",{method:"POST",body:{uid:x.uid,reason:r,durationMinutes:d?Number(d):undefined}}),"Usuário banido")}})
  ))));
  if(tab==="adm")for(const[k,t]of[["admins","Administradores"],["authorized","E-mails autorizados"]]){
    const i=h("input",{type:"email",placeholder:"email@exemplo.com"});
    c.append(pan(t,...L[k].map(e=>h("div",{className:"row"},h("div",{className:"i",textContent:e}),h("button",{className:"btn dan",textContent:"Remover",onclick:()=>act(()=>api("/admins",{method:"DELETE",body:{email:e,list:k}}),"Removido")}))),
      h("div",{className:"f"},i,h("button",{className:"btn pri",textContent:"Adicionar",onclick:()=>act(()=>api("/admins",{method:"POST",body:{email:i.value,list:k}}),"Adicionado")}))));
  }
  if(tab==="ia"){const m=h("input",{value:st.message||"",placeholder:"Mensagem exibida quando a IA estiver indisponível"});
    const set=(e,mt)=>act(()=>api("/states/ai",{method:"POST",body:{enabled:e,maintenance:mt,message:m.value}}),"Estado salvo");
    c.append(pan(st.enabled?"● IA ONLINE":"○ IA OFFLINE",m,h("div",{className:"f"},
      h("button",{className:"btn "+(st.enabled?"dan":"pri"),textContent:st.enabled?"Desativar IA":"Ativar IA",onclick:()=>set(!st.enabled,st.maintenance)}),
      h("button",{className:"btn",textContent:st.maintenance?"Remover manutenção":"Manutenção",onclick:()=>set(st.enabled,!st.maintenance)}),
      h("button",{className:"btn",textContent:"Salvar mensagem",onclick:()=>set(st.enabled,st.maintenance)}))))}
  if(tab==="msg"){const ti=h("input",{value:ms.title||"",placeholder:"Título"}),tx=h("textarea",{value:ms.message||"",placeholder:"Mensagem",rows:3}),ty=h("select");
    ["info","warning","maintenance","announcement"].forEach(o=>ty.append(h("option",{value:o,textContent:o,selected:o===(ms.type||"info")})));
    const en=h("input",{type:"checkbox",checked:!!ms.enabled,style:"width:auto"});
    c.append(pan("Mensagem exibida no chat",ti,h("div",{style:"height:8px"}),tx,h("div",{className:"f"},ty,h("label",{className:"row",style:"border:0"},en," Ativa")),
      h("div",{className:"f"},h("button",{className:"btn pri",textContent:"Salvar",onclick:()=>act(()=>api("/msg",{method:"POST",body:{enabled:en.checked,title:ti.value,message:tx.value,type:ty.value}}),"Mensagem salva")}),
      h("button",{className:"btn dan",textContent:"Excluir",onclick:()=>act(()=>api("/msg",{method:"DELETE"}),"Mensagem excluída")}))))}
}
load().catch(e=>toast(e.message));
