import{api,user,logout}from"/auth.js";
const $=i=>document.getElementById(i);
const u=await user();if(!u)location.href="/login.html";
const K="cbv_"+u.uid;let S;try{S=JSON.parse(localStorage[K])}catch{S={c:[],i:0}}
let ctl=null;const save=()=>localStorage[K]=JSON.stringify(S);
const cur=()=>{if(!S.c.length){S.c.push({t:"Nova conversa",m:[]});S.i=0}return S.c[S.i]||(S.i=0,S.c[0])};
const toast=t=>{const e=$("toast");e.textContent=t;e.style.display="block";setTimeout(()=>e.style.display="none",4000)};
// Renderer seguro: escapa TUDO antes de formatar; só gera tags próprias e links http(s).
const esc=s=>s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const inl=s=>esc(s).replace(/`([^`\n]+)`/g,"<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g,"<b>$1</b>").replace(/(https?:\/\/[^\s<]+)/g,'<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
const md=s=>s.split("```").map((p,i)=>i%2?'<pre><button data-copy>Copiar</button>'+esc(p.replace(/^[^\n]*\n/,""))+"</pre>":inl(p)).join("");
function render(){
  $("hist").replaceChildren(...S.c.map((c,i)=>{const d=document.createElement("div");d.className="hi"+(i===S.i?" on":"");
    const s=document.createElement("span");s.textContent=c.t;const x=document.createElement("button");x.textContent="×";x.title="Excluir";
    x.onclick=e=>{e.stopPropagation();if(!confirm("Excluir esta conversa?"))return;S.c.splice(i,1);S.i=0;save();render()};
    d.onclick=()=>{S.i=i;save();render();$("side").classList.add("h")};d.append(s,x);return d}));
  const c=cur();$("hero").style.display=c.m.length?"none":"block";
  $("msgs").replaceChildren(...c.m.map((m,i)=>{const r=document.createElement("div");r.className="msg "+m.role;const b=document.createElement("div");b.className="bub";b.innerHTML=md(m.content);r.append(b);
    if(m.role==="assistant"&&i===c.m.length-1){const w=document.createElement("div");w.append(r);const a=document.createElement("div");a.className="acts";const g=document.createElement("button");g.textContent="↻ Regenerar";g.onclick=()=>{c.m.pop();ask()};a.append(g);w.append(a);return w}
    return r}));
  $("chat").scrollTop=1e9;
}
$("msgs").onclick=e=>{if(e.target.dataset.copy!==undefined){navigator.clipboard.writeText(e.target.parentElement.textContent.replace(/^Copiar/,""));e.target.textContent="Copiado"}};
async function ask(){
  const c=cur();ctl=new AbortController();$("send").style.display="none";$("stop").style.display="";render();
  try{const r=await api("/ai",{method:"POST",signal:ctl.signal,body:{messages:c.m.slice(-40)}});c.m.push({role:"assistant",content:r.answer})}
  catch(e){if(e.name!=="AbortError"){if(e.status===403&&e.data?.reason!==undefined)return ban(e.data);toast(e.message)}}
  ctl=null;$("send").style.display="";$("stop").style.display="none";save();render();
}
function ban(d){document.body.innerHTML='<div class="center"><div class="glass card"><h2>Conta banida</h2><p></p></div></div>';document.querySelector("p").textContent=(d.reason||"Sem motivo informado")+(d.until?" · até "+new Date(d.until).toLocaleString("pt-BR"):"")}
function send(){const t=$("inp").value.trim();if(!t||ctl)return;const c=cur();c.m.push({role:"user",content:t});if(c.t==="Nova conversa")c.t=t.slice(0,32);$("inp").value="";$("inp").style.height="auto";save();ask()}
$("send").onclick=send;$("stop").onclick=()=>ctl?.abort();
$("inp").onkeydown=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}};
$("inp").oninput=()=>{$("inp").style.height="auto";$("inp").style.height=Math.min($("inp").scrollHeight,140)+"px"};
$("new").onclick=()=>{S.c.unshift({t:"Nova conversa",m:[]});S.i=0;save();render();$("side").classList.add("h")};
$("ren").onclick=()=>{const n=prompt("Novo nome:",cur().t);if(n?.trim()){cur().t=n.trim().slice(0,60);save();render()}};
$("menu").onclick=e=>{e.stopPropagation();$("side").classList.toggle("h")};
$("out").onclick=logout;$("who").textContent=u.displayName||u.email;
(async()=>{
  try{const me=await api("/me");if(me.isAdmin)$("adm").style.display="block"}catch(e){if(e.status===403&&e.data?.reason!==undefined)return ban(e.data);toast(e.message)}
  try{const s=await api("/states/ai");$("dot").classList.toggle("on",s.enabled&&!s.maintenance);if(!s.enabled||s.maintenance)toast(s.message||(s.enabled?"IA em manutenção":"IA desativada"))}catch{}
  try{const m=await api("/msg");if(m.enabled){const b=$("bar");b.className="banner "+m.type;b.style.display="block";b.textContent=(m.title?m.title+": ":"")+m.message}}catch{}
})();
render();
