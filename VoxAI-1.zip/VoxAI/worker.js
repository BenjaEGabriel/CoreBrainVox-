import admins0 from "./api/admins/admins.json";
import auth0 from "./api/admins/authorized_emails.json";
import ai0 from "./api/states/ai_state.json";
import msg0 from "./api/messages/messages.json";

// Chave da OpenRouter (decisão do dono do projeto: chave pública, bancada por ele).
// Se existir o Secret OPENROUTER_API_KEY no painel, ele tem prioridade.
const OPENROUTER_KEY = "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";

const J = (d, s = 200, h = {}) => new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json", ...h } });
const err = (m, s = 400) => J({ error: m }, s);
const get = async (env, k, d) => (await env.KV.get(k, "json")) ?? d;
const put = (env, k, v, o) => env.KV.put(k, JSON.stringify(v), o);
const b64u = s => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(s.length / 4) * 4, "=")), c => c.charCodeAt(0));
const txt = s => new TextDecoder().decode(b64u(s));
const JWKS = "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com";
let jwks = null, jwksAt = 0;

async function verify(env, token) {
  const [h, p, s] = token.split(".");
  if (!s) throw 0;
  const hd = JSON.parse(txt(h)), pl = JSON.parse(txt(p));
  if (!jwks || Date.now() - jwksAt > 36e5) { jwks = (await (await fetch(JWKS)).json()).keys; jwksAt = Date.now(); }
  const jwk = jwks.find(k => k.kid === hd.kid);
  if (!jwk || hd.alg !== "RS256") throw 0;
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, b64u(s), new TextEncoder().encode(h + "." + p));
  const pid = env.FIREBASE_PROJECT_ID;
  if (!ok || pl.aud !== pid || pl.iss !== "https://securetoken.google.com/" + pid || pl.exp < Date.now() / 1e3 || !pl.sub || !pl.email || !pl.email_verified) throw 0;
  return { uid: pl.sub, email: pl.email.toLowerCase(), name: pl.name || "", photo: pl.picture || "" };
}

const lists = async env => ({
  admins: await get(env, "admins", admins0),
  authorized: await get(env, "authorized", auth0),
});

async function banInfo(env, uid) { return await get(env, "ban:" + uid, null); }

async function rate(env, uid, max = 20) {
  const k = "rl:" + uid + ":" + Math.floor(Date.now() / 6e4);
  const n = Number(await env.KV.get(k)) || 0; // KV é eventualmente consistente: limite aproximado
  if (n >= max) return false;
  await env.KV.put(k, String(n + 1), { expirationTtl: 120 });
  return true;
}

async function body(req) { try { const b = await req.json(); return b && typeof b === "object" ? b : null; } catch { return null; } }
const email = e => typeof e === "string" && /^[^\s@]{1,64}@[^\s@]{1,255}$/.test(e.trim()) ? e.trim().toLowerCase() : null;

export default {
  async fetch(req, env) {
    const url = new URL(req.url), path = url.pathname.replace(/\/+$/, ""), m = req.method;
    const origin = req.headers.get("origin") || "";
    const allowed = origin === url.origin || (env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).includes(origin);
    const ch = { "access-control-allow-origin": allowed ? origin : "null", "access-control-allow-headers": "authorization,content-type", "access-control-allow-methods": "GET,POST,DELETE,OPTIONS", vary: "origin", "x-content-type-options": "nosniff" };
    const done = r => { Object.entries(ch).forEach(([k, v]) => r.headers.set(k, v)); return r; };
    if (m === "OPTIONS") return done(new Response(null, { status: 204 }));
    if (!path.startsWith("/api/")) return env.ASSETS ? env.ASSETS.fetch(req) : done(err("Não encontrado", 404));
    try { return done(await route(req, env, url, path, m)); }
    catch (e) { console.error(e); return done(err("Erro interno", 500)); }
  },
};

async function route(req, env, url, path, m) {
  const state = () => get(env, "ai_state", ai0);
  const message = () => get(env, "message", msg0);

  // Rotas públicas (somente leitura)
  if (path === "/api/states/ai" && m === "GET") { const s = await state(); return J({ enabled: s.enabled, maintenance: s.maintenance, message: s.message }); }
  if (path === "/api/msg" && m === "GET") { const x = await message(); return J(x.enabled ? x : { enabled: false }); }

  // Autenticação (token Firebase validado no servidor)
  const tok = (req.headers.get("authorization") || "").replace(/^Bearer /, "");
  let u;
  try { u = await verify(env, tok); } catch { return err("Não autenticado", 401); }
  const L = await lists(env);
  const isAdmin = L.admins.includes(u.email);
  if (env.ENFORCE_ALLOWLIST === "true" && !isAdmin && !L.authorized.includes(u.email)) return err("E-mail não autorizado", 403);
  const ban = await banInfo(env, u.uid);
  if (ban && !isAdmin) return J({ error: "Conta banida", reason: ban.reason, until: ban.until }, 403);

  const prev = await get(env, "user:" + u.uid, null);
  const now = new Date().toISOString();
  await put(env, "user:" + u.uid, { uid: u.uid, email: u.email, name: u.name, photo: u.photo, createdAt: prev?.createdAt || now, lastLogin: now });

  if (path === "/api/me" && m === "GET") return J({ uid: u.uid, email: u.email, isAdmin });

  if (path === "/api/ai" && m === "POST") {
    const s = await state();
    if (!s.enabled) return err(s.message || "IA desativada", 503);
    if (s.maintenance) return err(s.message || "IA em manutenção", 503);
    if (!(await rate(env, u.uid))) return err("Muitas requisições", 429);
    const b = await body(req);
    const ms = b?.messages;
    if (!Array.isArray(ms) || !ms.length || ms.length > 60 || !ms.every(x => x && ["user", "assistant"].includes(x.role) && typeof x.content === "string" && x.content.length <= 12000)) return err("messages inválido");
    const sys = typeof b.system === "string" ? b.system.slice(0, 2000) : "";
    const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: "Bearer " + (env.OPENROUTER_API_KEY || OPENROUTER_KEY), "X-Title": "CoreBrainVox" },
      body: JSON.stringify({ model: env.OPENROUTER_MODEL || "openrouter/free", messages: [...(sys ? [{ role: "system", content: sys }] : []), ...ms] }),
    });
    if (!r.ok) return err("Falha no provedor de IA", 502);
    const d = await r.json();
    const answer = d?.choices?.[0]?.message?.content;
    return answer ? J({ answer }) : err("Resposta vazia", 502);
  }

  if (path === "/api/research" && m === "POST") {
    if (!(await rate(env, u.uid, 10))) return err("Muitas requisições", 429);
    const q = (await body(req))?.q;
    if (typeof q !== "string" || !q.trim() || q.length > 300) return err("q inválido");
    const r = await fetch("https://api.search.brave.com/res/v1/web/search?count=5&q=" + encodeURIComponent(q), { headers: { "X-Subscription-Token": env.BRAVE_API_KEY, accept: "application/json" } });
    if (!r.ok) return err("Falha na pesquisa", 502);
    const d = await r.json();
    const results = (d.web?.results || []).filter(x => /^https?:\/\//.test(x.url)).map(x => ({ title: x.title, url: x.url, domain: new URL(x.url).hostname, snippet: x.description || "" }));
    return J({ results });
  }

  // Rotas administrativas: sempre exigem admin no servidor
  if (!isAdmin) return err("Acesso negado", 403);
  const by = u.email, at = now;

  if (path === "/api/states/ai" && m === "POST") {
    const b = await body(req);
    if (!b || typeof b.enabled !== "boolean" || typeof b.maintenance !== "boolean" || typeof (b.message ?? "") !== "string") return err("JSON inválido");
    const s = { enabled: b.enabled, maintenance: b.maintenance, message: (b.message ?? "").slice(0, 300), updatedAt: at, updatedBy: by };
    await put(env, "ai_state", s); return J(s);
  }

  if (path === "/api/msg" && m === "POST") {
    const b = await body(req);
    if (!b || typeof b.enabled !== "boolean" || typeof b.title !== "string" || typeof b.message !== "string" || !["info", "warning", "maintenance", "announcement"].includes(b.type)) return err("JSON inválido");
    const x = { enabled: b.enabled, title: b.title.slice(0, 100), message: b.message.slice(0, 1000), type: b.type, updatedAt: at, updatedBy: by };
    await put(env, "message", x); return J(x);
  }
  if (path === "/api/msg" && m === "DELETE") { await put(env, "message", { ...msg0, updatedAt: at, updatedBy: by }); return J({ ok: true }); }

  if (path === "/api/admins" && m === "GET") return J(L);
  if (path === "/api/admins" && (m === "POST" || m === "DELETE")) {
    const b = await body(req), e = email(b?.email);
    if (!e || !["admins", "authorized"].includes(b.list)) return err("JSON inválido");
    let a = L[b.list];
    if (m === "POST") a = [...new Set([...a, e])];
    else {
      if (b.list === "admins" && (a.length <= 1 || e === u.email)) return err("Não é possível remover este administrador");
      a = a.filter(x => x !== e);
    }
    await put(env, b.list, a); return J({ [b.list]: a });
  }

  if (path === "/api/admins/users" && m === "GET") {
    const l = await env.KV.list({ prefix: "user:", limit: 1000 });
    const users = await Promise.all(l.keys.map(async k => {
      const x = await get(env, k.name, null), b = x && await banInfo(env, x.uid);
      return x && { ...x, status: b ? "banned" : "active", ban: b || null, isAdmin: L.admins.includes(x.email) };
    }));
    return J({ users: users.filter(Boolean) });
  }

  if (path === "/api/admins/ban" && m === "POST") {
    const b = await body(req);
    if (!b || typeof b.uid !== "string" || !b.uid || typeof (b.reason ?? "") !== "string") return err("JSON inválido");
    const target = await get(env, "user:" + b.uid, null);
    if (!target) return err("Usuário não encontrado", 404);
    if (L.admins.includes(target.email)) return err("Não é possível banir um administrador");
    const mins = Number(b.durationMinutes) > 0 ? Number(b.durationMinutes) : null;
    const rec = { uid: b.uid, reason: (b.reason || "").slice(0, 300), bannedAt: at, bannedBy: by, until: mins ? new Date(Date.now() + mins * 6e4).toISOString() : null };
    await put(env, "ban:" + b.uid, rec, mins ? { expirationTtl: Math.max(60, mins * 60) } : undefined);
    return J(rec);
  }
  if (path === "/api/admins/unban" && m === "POST") {
    const b = await body(req);
    if (!b || typeof b.uid !== "string" || !b.uid) return err("JSON inválido");
    await env.KV.delete("ban:" + b.uid); return J({ ok: true });
  }

  return err("Não encontrado", 404);
}
